package pages;


import wrappers.GenericWrappers;

public class Login extends GenericWrappers
{

	
	public Login enterusername(String data)
	{
		enterbyid("username", data);
		return this;
		
	}
	public Login enterpassword(String data)
	{
		enterbyid("password", data);
		return this;
		
	}
	public MainPage clicklogin()
	{
		clickbyid("t1li");
		return new MainPage();
		
	}
public MainPage clickgooglesignin()
{
	clickbyclass("abcRioButtonContentWrapper");
	switchToLastWindow();
	enterbyid("identifierId", "qateamone1");
	clickbyclass("CwaK9");
	//enterByName("password", "Broadsoft123$");
	enterByXpath("//*[@id='password']", "Broadsoft123$");
	clickbyxpath("//*[@id=\'passwordNext\']/content/span");
	return new MainPage();
}
}

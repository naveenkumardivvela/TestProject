package pages;


import wrappers.GenericWrappers;

public class MainPage extends GenericWrappers
{

	public MainPage createNewWS(String Wsname) throws InterruptedException
	{
		clickbyclass("new_workspace_icon");
		enterbyid("workspaceNameInput", Wsname);
		Thread.sleep(3000);
		enterByXpath("//*[@id=\'create-project-view\']/div[2]/div[4]/div[3]/div/textarea", "Test description");
		Thread.sleep(3000);
		clickbyid("createWorkspaceButton");
		Thread.sleep(3000);
		clickbyid("dialogCloseButton");
		return this;
	}
	public MainPage verifyCreatedWS(String wsname)
	{
		verifyTextContainsByclass("workspace-tabs-ws-name", wsname);
		return this;
	}
	//This method is to create quick note
	public MainPage createQNote(String quicknote)
	{
		clickbyxpath("//*[@id='project_home_page']/div/div[1]/div/div[2]/div[4]");
		enterByXpathandEnter("//*[@id='inote-dashboard-right']/div/div[2]/div[2]/div/div[2]/div/textarea", quicknote);
		return this;
		//div[@class="note-cell-title "] 
		//span[contains(text(), 'QN 2')]
	}
	
	//This method is to open quick note
	public MainPage openQNote()
	{
		clickbyxpath("//span[contains(text(), 'QN 2')]");
		return this;
	}
	//This method is to edit note
		public MainPage editNote()
		{
			switchFrameUsingId(1);
			enterByXpath("//div[@class='placeholder']", "Edit the content of the note");
			return this;
		}
		//This method is to add tag
		public MainPage addTag()
		{
			enterByXpathandEnter("//*[@id='inote-dashboard-right']/div/div[3]/div[2]/div/div[2]/div[2]/div/div[7]/div[2]/div[3]/div/div/div/div[1]/div[2]/div[2]/div/div/div[1]/div/input", "test");
		 	return this;
		}
	
	public MainPage verifyuser()
	{
		//verifyTextContainsByclass("topbar-username", "vijayalakshmi");
		verifyTextContainsByXpath("//*[@id=\'topbar-userprofile\']/div[2]/div[1]",  "vijayalakshmi");
		return this;
	}
	public Login logout()
	{
		clickbyxpath("//*[@id=\'topbar-userprofile\']/div[1]/span");
		return new Login();

	}

}

package testcase;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.TestDataProvider;
public class TC_Workspace extends pages.MainPage
{
	
		@DataProvider(name = "fetchData")
		public Object[][] getData() 
		{
			return TestDataProvider.getSheet("TC001");
		}

		
		@Test(dataProvider="fetchData")
		public void login(String uname,String pwd) throws InterruptedException
		{
		   // createNewWS("QA_Testws aug27.1");
		   // verifyCreatedWS("QA_Testws aug27.1");
		   // createQNote("QN 3");
			openQNote();
		    editNote();
		    addTag();
		    
		}
	}


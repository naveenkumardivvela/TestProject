package testcase;

import org.testng.annotations.Test;


public class TC_Googlesignin extends pages.Login
{
	@Test
	public void login()
	{
	    launch();
	    clickgooglesignin();
	}
}
